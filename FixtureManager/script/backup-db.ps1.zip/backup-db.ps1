cp c:\home\site\wwwroot\local.db c:\home\data\backups\local.db-$(get-date -f yyyy-MM-dd) 

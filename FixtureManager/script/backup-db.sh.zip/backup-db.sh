powershell cp c:\home\site\wwwroot\local.db c:\home\data\local.db-$(get-date -f yyyy-MM-dd) 
